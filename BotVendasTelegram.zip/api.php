<?php

$arquivo = 'payment_process';
function connect(){
    $servername = "localhost";
$username = "id19034923_pagamentodb";
$password = "Renato\$96475870";
$dbname   = "id19034923_pagamento";

$conn = new mysqli($servername, $username, $password, $dbname);
 return $conn;
}

function inserirDados($paymentid, $chatid, $conn){
    
$query = "INSERT INTO Pagamentos (paymentid, chatid)
VALUES ($paymentid, $chatid)";

if ($conn->query($query) === TRUE) {
  return true;
} else {
  return false;
}

}

function criarTabela($conn){
   // código sql para criar a tabela
// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS Pagamentos (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
paymentid VARCHAR(30) NOT NULL,
chatid VARCHAR(30) NOT NULL,
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

  if ($conn->query($sql) === TRUE) {
  return true;
} else {
   return false;
}


}


if(isset($_POST)){
    
    $chatid = "";
    $paymentid = "";
    
    if(!empty($_POST["chatId"]) && !empty($_POST["paymentID"])){
        
        $chatid = $_POST["chatId"];
        $paymentid = $_POST["paymentID"];
    }
    
    
    $conn = connect();
   if( criarTabela($conn) ){
       if(inserirDados($paymentid, $chatid, $conn)){
           echo "Salvo";
       }
   }
   
}else if(isset($_GET)){
    
    
    echo "GET";
      
}
    

    
    
?>