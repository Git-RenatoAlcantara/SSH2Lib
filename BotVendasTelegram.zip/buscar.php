<?php

function connect(){
    $servername = "localhost";
$username = "id19034923_pagamentodb";
$password = "Renato\$96475870";
$dbname   = "id19034923_pagamento";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  return "";
}

 return $conn;
}


 
 

function selecionarPagamento($paymentid){
    
    $conn = connect();
    
   $getChatId = "";
   
   $query= "SELECT * FROM Pagamentos";
    
    $result = $conn->query($query);
    
    if($result->num_rows > 0){
        $cont = 0;
        while($row = $result->fetch_assoc()){
           //  print_r($row);
             
             if($row["paymentid"]== $paymentid){
                 $getChatId = $row["chatid"];
             }
        }
    }
    
    return $getChatId;
}

/**if(isset($_GET) && !empty($_GET["paymentId"])){
   
    $paymentId = $_GET["paymentId"];
 
   $conn = connect();
   if(!empty($conn)){
      $result =  selecionarPagamento($conn, $paymentId);
        if(empty($result)) echo "vazio";
        if(!empty($result)) echo $result;
   }
    
}
**/
function enviarUsuario($chatId, $sshUser, $sshPass){
 $apiToken = "5364826966:AAGfUb1i8HZsEHbHPfUmnxerkbITyig_WJk";
 $html ="
 <b>Conta criada com sucesso!</b>
 
 <b>Usuário:</b> <i> $sshUser</i>
 <b>Senha:</b><i> $sshPass</i>
 <b>Validade:</b> 30 Dias
 <b>VIVO | TIM | CLARO</b>
 
 <b>Contato:</b> @N00neMod";
$data = [
      'chat_id' => $chatId,
      'text' => $html,
      'parse_mode' => 'html'
  ];
  

$url= "https://api.telegram.org/bot".$apiToken."/sendMessage?parse_mode=HTML&chat_id=".$chatId."&text=".urlencode($html);

file_get_contents($url);
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $post = file_get_contents('php://input');
    $array = (array) json_decode($post);
    
    if(!empty($array["action"])){
        $data = $array["data"];
        $id = (array) $data;
        $chatId = selecionarPagamento($id["id"]);
        if(!empty($chatId)){
            enviarUsuario($chatId, "N00neMod", "N00neMod1234");
        };
    }
    
}else if (isset($_GET)){
    echo "GET";
    
}
